struct User {
    username: String,
    email: String,
    sign_in_count: u64,
    active: bool,
}

fn main() {
    let mut user = User {
        username: String::from("abc"),
        email: String::from("abc@163.com"),
        active: true,
        sign_in_count: 556,
    };

    println!("{}", user.email);

    let mut user1 = User {
        username: String::from("abc"),
        email: String::from("abc@163.com"),
        ..user //更新语法
    };

    println!("{}", user1.email);

    user.email = String::from("value@example.com");

    println!("{}", user.email);
}

fn buil_user(email: String, username: String) -> User {
    User {
        username,
        email,
        active: true,
        sign_in_count: 556,
    }
}

fn strutct_tuples() {
    struct Color(i32, i32, i32);
    struct Point(i32, i32, i32);
    let black = Color(1, 1, 1);
    let origin = Point(0, 0, 0);
}
