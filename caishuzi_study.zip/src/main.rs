use rand::Rng;
use std::cmp::Ordering;
use std::io;

fn main() {
    println!("猜数");

    let shueiji = rand::thread_rng().gen_range(0..101);
    //产生一个为shueiji的随机数范围是101以下包含0以上

    loop {
        let mut guess = String::new();
        //创建可变空字符串

        io::stdin().read_line(&mut guess).expect("无法读取");
        //读取检查

        println!("您猜测的数是：{}", guess);
        //输入语句

        let guess: u32 = match guess.trim().parse() {
            Ok(num) => num,
            Err(_) => continue,
        };
        //类型转换/.trim()去除两端空白/.parse()解析数据类型转换为指定类型/.expect()返回字符

        match guess.cmp(&shueiji) {
            //判断语句
            Ordering::Less => println!("Too small"),
            Ordering::Equal => {
                println!("of course");
                break;
            }
            Ordering::Greater => println!("Too big"),
        }
    }
}
